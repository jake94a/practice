"""
Description:
This is a practice challenge from Codecademy 'Learn Python 3' course
The goal is to read in some email.txt files and censor words from them

Function:
Read in the .txt files

"""

email_one = open('email_one.txt', 'r').read()
email_two = open('email_two.txt', 'r').read()
email_three = open('email_three.txt', 'r').read()
email_four = open('email_four.txt', 'r').read()

proprietary_terms = ['she', 'personality matrix']


def censorship(words_to_sensor, words_to_scan):
    lowercase_scan = words_to_scan.lower()
    lowercase_censor_word = words_to_sensor.lower()
    replacement_char = '#'
    join_char = ''
    replacement_list = []
    if lowercase_censor_word in lowercase_scan:
        print(True)
    for i in range(len(words_to_sensor)):
        replacement_list.append(replacement_char)
    censored_word = join_char.join(replacement_list)
    output_text = words_to_scan.replace(words_to_sensor, censored_word)
    print(output_text)


censorship('Learning algorithms', email_one)
